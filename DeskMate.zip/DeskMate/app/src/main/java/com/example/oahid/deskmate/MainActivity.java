package com.example.oahid.deskmate;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private final String DEVICE_ADDRESS="00:18:E4:0A:00:01";
    private final UUID PORT_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");//Serial Port Service ID
    private BluetoothDevice device;
    private BluetoothSocket socket;
    private OutputStream outputStream;
    private InputStream inputStream;
    Button startButton, sendButton,stopButton;
    EditText editTextRoutine, editTextRepTask, editTextIndvTask, editTextGagtCtrl;
    LinearLayout controlLayout;
    String outputDataStream;
    boolean deviceConnected=false;
    byte buffer[];
    boolean stopThread;
    byte msgBuffer[];

    int i=0, j=0;
    int strLen;
    String outputSubString;
    long loadingTime;

    CountDownTimer loader;

    SharedPreferences dataBox;
    SharedPreferences.Editor spEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startButton = (Button) findViewById(R.id.buttonStart);
        sendButton = (Button) findViewById(R.id.buttonSend);
        stopButton = (Button) findViewById(R.id.buttonStop);
        editTextRoutine = (EditText) findViewById(R.id.editRoutine);
        editTextRepTask = (EditText)findViewById(R.id.editRepeatedTasks);
        editTextIndvTask = (EditText) findViewById(R.id.editIndvTasks);
        editTextGagtCtrl = (EditText) findViewById(R.id.editGagtCtrl);
        controlLayout = (LinearLayout) findViewById(R.id.control_layout);

        dataBox = getSharedPreferences("savedData", MODE_PRIVATE);
        spEditor = dataBox.edit();

        setUiEnabled(false);

        //Setting saved data
        editTextRoutine.setText(dataBox.getString("routine", ""));
        editTextRepTask.setText(dataBox.getString("repTask",""));
        editTextIndvTask.setText(dataBox.getString("indvTask",""));
        editTextGagtCtrl.setText(dataBox.getString("gagtCtrl",""));
    }

    public void setUiEnabled(boolean bool)
    {
        startButton.setEnabled(!bool);
        sendButton.setEnabled(bool);
        stopButton.setEnabled(bool);
        //textView.setEnabled(bool);

    }

    public boolean BTinit()
    {
        boolean found=false;
        BluetoothAdapter bluetoothAdapter=BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(),"Device doesnt Support Bluetooth",Toast.LENGTH_SHORT).show();
        }
        if(!bluetoothAdapter.isEnabled())
        {
            Intent enableAdapter = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableAdapter, 0);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Set<BluetoothDevice> bondedDevices = bluetoothAdapter.getBondedDevices();
        if(bondedDevices.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"Please Pair the Device first",Toast.LENGTH_SHORT).show();
        }
        else
        {
            for (BluetoothDevice iterator : bondedDevices)
            {
                if(iterator.getAddress().equals(DEVICE_ADDRESS))
                {
                    device=iterator;
                    found=true;
                    break;
                }
            }
        }
        return found;
    }

    public boolean BTconnect()
    {
        boolean connected=true;
        try {
            socket = device.createRfcommSocketToServiceRecord(PORT_UUID);
            socket.connect();
        } catch (IOException e) {
            e.printStackTrace();
            connected=false;
        }
        if(connected)
        {
            try {
                outputStream=socket.getOutputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                inputStream=socket.getInputStream();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }


        return connected;
    }

    public void onClickStart(View view) {
        //editText.setText("");
        //textView.setBackgroundColor(getResources().getColor(R.color.normal));
        if(BTinit())
        {
            if(BTconnect())
            {
                setUiEnabled(true);
                deviceConnected=true;
                beginListenForData();
                //textView.setText("You are connected");
                Toast.makeText(this, "You are connected", Toast.LENGTH_LONG).show();
                sendButton.setVisibility(View.VISIBLE);
            }

        }
    }

    void beginListenForData()
    {
        final Handler handler = new Handler();
        stopThread = false;
        buffer = new byte[1024];
        Thread thread  = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopThread)
                {
                    try
                    {
                        int byteCount = inputStream.available();
                        if(byteCount > 0)
                        {
                            byte[] rawBytes = new byte[byteCount];
                            inputStream.read(rawBytes);
                            final String string=new String(rawBytes,"UTF-8");
                            handler.post(new Runnable() {
                                public void run()
                                {
                                    //textView.setText(string);
                                }
                            });

                        }
                    }
                    catch (IOException ex)
                    {
                        stopThread = true;
                    }
                }
            }
        });

        thread.start();
    }

    public void onClickSend(View view) {
        //Getting all the tasks from each of the editText box.
        String routineInput = editTextRoutine.getText().toString();
        String repTaskInput = editTextRepTask.getText().toString();
        String indvTaskInput = editTextIndvTask.getText().toString();
        String gagtCtrlInput = editTextGagtCtrl.getText().toString();

        //Saving Data
        spEditor.putString("routine", routineInput);
        spEditor.putString("repTask", repTaskInput);
        spEditor.putString("indvTask", indvTaskInput);
        spEditor.putString("gagtCtrl", gagtCtrlInput);
        spEditor.commit();

        i=0;
        j=0;


        //Putting all strings together for uploading to the device
        outputDataStream = routineInput+"*"+repTaskInput+"*"+indvTaskInput+"*"+gagtCtrlInput+"*";
        strLen = outputDataStream.length();
        loadingTime = ((strLen/20)+2)*1000;



        loader = new CountDownTimer(loadingTime, 500) {

            @Override
            public void onTick(long millisUntilFinished) {
                if(i==strLen||i>strLen){
                    Toast.makeText(MainActivity.this, "Done uploading", Toast.LENGTH_SHORT).show();
                }
                else if(j+20>strLen){
                    j=strLen;
                    outputSubString = outputDataStream.substring(i,j);
                    msgBuffer = outputSubString.getBytes();
                    try {
                        outputStream.write(msgBuffer);
                        //toast();

                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                        //e.printStackTrace();
                    }
                }
                else{
                    j=i+20;
                    outputSubString = outputDataStream.substring(i,j);
                    outputSubString = outputDataStream.substring(i,j);
                    msgBuffer = outputSubString.getBytes();
                    try {
                        outputStream.write(msgBuffer);
                        //toast();

                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                        //e.printStackTrace();
                    }
                }


                //Toast.makeText(MainActivity.this, "Tanin", Toast.LENGTH_SHORT).show();
                i+=20;
            }

            @Override
            public void onFinish() {
                Toast.makeText(MainActivity.this, "Done!", Toast.LENGTH_SHORT).show();
            }
        }.start();

    }



    /*public void onClickSend(View view) {
        //Getting all the tasks from each of the editText box.
        String routineInput = editTextRoutine.getText().toString();
        String repTaskInput = editTextRepTask.getText().toString();
        String indvTaskInput = editTextIndvTask.getText().toString();
        String gagtCtrlInput = editTextGagtCtrl.getText().toString();

        //Saving Data
        spEditor.putString("routine", routineInput);
        spEditor.putString("repTask", repTaskInput);
        spEditor.putString("indvTask", indvTaskInput);
        spEditor.putString("gagtCtrl", gagtCtrlInput);
        spEditor.commit();

        int i=0, j=0;
        int strLen;

        //Putting all strings together for uploading to the device
        outputDataStream = "#6.00-7.30: weak up #7.30-8.30: Breakfast*#9.00:(mo,th): jim#25/7,17.00:NID Correction#6.30: on";
        strLen = outputDataStream.length();
        int loadingTime = outputDataStream.length()/10;
        while(loadingTime>=0){

            if(i>strLen){
                //this.onFinish();
                break;
            }
            j=i+10;
            if(i<strLen&&j>strLen){
                j=strLen;
            }
            dataSubString=outputDataStream.substring(i,j);
            msgBuffer = dataSubString.getBytes();

            i=i+10;

            new CountDownTimer(5000, 1000) {

                public void onTick(long millisUntilFinished) {

                }
                public void onFinish() {
                    try {
                        outputStream.write(msgBuffer);
                        toast();

                    } catch (IOException e) {
                        Toast.makeText(MainActivity.this, e.toString(), Toast.LENGTH_SHORT).show();
                        //e.printStackTrace();
                    }
                }
            }.start();

            loadingTime--;
        }

    }*/


    public void toast(){
        Toast.makeText(this, outputSubString, Toast.LENGTH_SHORT).show();
    }

    public void onClickStop(View view) throws IOException {
        stopThread = true;
        outputStream.close();
        inputStream.close();
        socket.close();
        setUiEnabled(false);
        deviceConnected=false;
        Toast.makeText(this, "Connection Closed!", Toast.LENGTH_SHORT).show();
        sendButton.setVisibility(View.GONE);
    }


}
